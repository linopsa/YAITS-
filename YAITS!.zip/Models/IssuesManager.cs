﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace YAITS_.Models
{
    public class IssuesManager
    {
        List<Issues> issues = new List<Issues>();
        
        public IssuesManager()
        {
            LoadFromDB();
        }

        private void LoadFromDB()
        {
            //throw new NotImplementedException();
        }

        public void AddIssue(Issues issue)
        {
            CheckIfUnique(issue);
            issues.Add(issue);
            SavetoDB(issue);
        }

        public void UpdateIssue(Issues issue, Issues newIssue)
        {
            //throw new NotImplementedException();
        }

        private void CheckIfUnique(Issues issue)
        {
            for (int i = 0; i < issues.Count; i++)
            {
                if (issue.GetShortDescription().Equals(issues[i].GetShortDescription()))
                {
                    throw new Exception("The issue already exists");
                }
            }
        }

        private void SavetoDB(Issues issue)
        {
            //throw new NotImplementedException();
        }

        public List<Issues> GetIssues()
        {
            return issues;
        }

        public void DeleteIssue(string shortDescription)
        {
            for(int i = 0; i < issues.Count; i++)
            {
                if(shortDescription.Equals(issues[i].GetShortDescription()))
                {
                    issues.RemoveAt(i);
                    DeleteFromDB(issues[i]);
                }
            }
        }

        private void DeleteFromDB(Issues issues)
        {
            //throw new NotImplementedException();
        }
    }
}
